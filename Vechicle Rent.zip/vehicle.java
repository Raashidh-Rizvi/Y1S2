


public class vehicle {
    private String model;
    private double rentalPerDay;

    vehicle(String model,Double rentalPerDay){
        this.model=model;
        this.rentalPerDay=rentalPerDay;
    }

    public double calculateRentalcost(int days){
        return rentalPerDay*days;
    }

}
class car extends vehicle{
    private int numSeats;
    car(String model,Double rentalPerDay,int numSeats){
        super( model,rentalPerDay);
        this.numSeats=numSeats;
    }

}

class motorcycle extends vehicle {
    private int engineCapacity;

    motorcycle(String model, Double rentalPerDay, int engineCapacity) {
        super(model, rentalPerDay);
        this.engineCapacity = engineCapacity;
    }


    public static void main(String[] args) {

        motorcycle bike = new motorcycle("bajaj", 1000.00, 150);
        car car = new car("bmw", 10000.00, 5);
        System.out.println("Total Rent for the Car " + car.calculateRentalcost(5));
        System.out.println("Total Rent For the bike " + bike.calculateRentalcost(5));
    }
}