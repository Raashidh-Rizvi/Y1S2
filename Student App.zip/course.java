public class course extends student {
    private String courseName;

    course(String name, int age, String courseName) {
        super(name, age);
        this.courseName = courseName;

    }

    public void displayCourseInfo() {
        super.displayInfo();
        System.out.println("Course Name : " + courseName);

    }

}