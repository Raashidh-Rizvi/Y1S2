public class student {
    private String name;
    private int age;

    student(String name,int age){
        this.name = name;
        this.age = age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void displayInfo(){
        System.out.println("Student Name : "+ name);
        System.out.println("Student Age : "+ age);
    }


}
