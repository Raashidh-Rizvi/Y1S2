public class StudentApp{
            public static void main (String []args){
            course course = new course("Ilham", 30, "MC");
                course course1 = new course("kusini", 29, "DM");

            course.displayCourseInfo();
                System.out.println();
            course1.displayCourseInfo();


            }


        }

